﻿# NovaLume Time-Series Storage

InfluxDB 3 Core stack for storing NILM ML predictions and meter telemetry.

## What This Is

Two time-series data categories are stored:

| Data | Source | Retention |
|------|--------|-----------|
| ML predictions | Disaggregation model via MQTT | 90 days |
| Meter snapshots | Smart meter via MQTT (future) | 14 days |

## Architecture

    ML Model / Smart Meter
            |
            | MQTT (broker.hivemq.com:1883)
            v
        Telegraf
            |
            | HTTP write
            v
    InfluxDB 3 Core (:8181)
            |
            v
    Explorer UI (:8888)

## Quick Start

1. Install Docker Desktop.
2. Copy this folder to your machine.
3. In a terminal:  docker compose up -d
4. Open http://localhost:8888 in your browser.
5. Click + Add Server and enter:
   - Server URL: http://host.docker.internal:8181
   - Token: (shared separately, ask a teammate)

## Common Queries

In Explorer UI -> Query Data, select database `predictions`:

Latest 10 predictions:
    SELECT * FROM ml_predictions ORDER BY time DESC LIMIT 10;

Hourly average power (one appliance, last 24h):
    SELECT date_bin(INTERVAL ''1 hour'', time) AS hour,
           AVG(powerkw) AS avg_powerkw
    FROM ml_predictions
    WHERE id = ''<appliance-uuid>''
      AND time > now() - INTERVAL ''24 hours''
    GROUP BY hour
    ORDER BY hour;

Daily energy consumption (kWh, last 7 days):
    SELECT id,
           date_bin(INTERVAL ''1 day'', time) AS day,
           AVG(powerkw) * 24 AS kwh
    FROM ml_predictions
    WHERE time > now() - INTERVAL ''7 days''
    GROUP BY id, day
    ORDER BY id, day;

## Full Docs

See SETUP.md for installation, HANDOFF.md for technical reference.

## Key Notes

- Query language is SQL, not Flux (InfluxDB 3 changed this).
- Databases, not buckets.
- Retention is immutable after database creation.
- Ports: 8181 (API), 8888 (UI).
